export class Employee {
    id!: number;
    firstName!: string;
    lastName!:string;
    emailId!:string;
    phoneNumber!: number;
    designation!: string;
    salary!: number;
    state!: string;
    dateColumn!:Date;
    fileData!: File;
}

