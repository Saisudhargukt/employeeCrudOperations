package com.student.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySpringbootBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
